﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MarkMonitor.LinkCrawler.Data;
using MarkMonitor.LinkCrawler.Web.Models;

namespace MarkMonitor.LinkCrawler.Web.Controllers
{
    public class HomeController : Controller
    {
	    private readonly IStoredLinkRepository _storedLinkRepository;

	    public HomeController(IStoredLinkRepository storedLinkRepository)
	    {
		    _storedLinkRepository = storedLinkRepository;
	    }

	    public ActionResult Index()
        {
            return View(new HomeModel(_storedLinkRepository));
        }

    }
}
