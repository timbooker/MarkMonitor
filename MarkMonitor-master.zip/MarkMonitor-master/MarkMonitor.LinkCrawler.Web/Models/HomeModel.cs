using System.Collections.Generic;
using System.Linq;
using MarkMonitor.LinkCrawler.Data;

namespace MarkMonitor.LinkCrawler.Web.Models
{
	public class HomeModel
	{
		private readonly IStoredLinkRepository _storedLinkRepository;

		public HomeModel(IStoredLinkRepository storedLinkRepository)
		{
			_storedLinkRepository = storedLinkRepository;
		}

		public IEnumerable<StructuredStoredLink> GetLinks()
		{
			var parentItems = GetLinksForParentIdOf(0).Select(x => new StructuredStoredLink(x)).ToList();

			foreach(var item in parentItems)
			{
				BuildLinks(item);
			}

			return parentItems;
		}

		public string GetNodeClass(StructuredStoredLink link)
		{
			return link.HasChildren() ? "folder" : "file";
		}

		private void BuildLinks(StructuredStoredLink link)
		{
			link.Children =new List<StructuredStoredLink>();
			link.Children.AddRange(GetLinksForParentIdOf(link.Id).Select(x => new StructuredStoredLink(x)));
			foreach(var item in link.Children)
			{
				BuildLinks(item);
			}
		}

		private IEnumerable<StoredLink> GetLinksForParentIdOf(int parentId)
		{
			return _storedLinkRepository.GetAll()
										.Where(x => x.ParentId == parentId);
		}
	}
}